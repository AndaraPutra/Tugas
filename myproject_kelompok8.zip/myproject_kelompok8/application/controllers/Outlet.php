<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Outlet extends CI_Controller {

    function __construct()
    {
        parent::__construct();

        $this->load->model('m_data');

        if($this->session->userdata('status')!="telah_login"){
            redirect(base_url().'login?alert=belum_login');
        }
    }

    // CRUD outlet
    public function index()
    {
        $data['outlet'] = $this->m_data->get_data('tb_outlet')->result();
        $this->load->view('template/header');
        $this->load->view('outlet/data',$data);
        $this->load->view('template/footer');

    }

    public function outlet_tambah()
    {
        $this->load->view('template/header');
        $this->load->view('outlet/input');
        $this->load->view('template/footer');
    }
    public function outlet_aksi()
    {

        $this->form_validation->set_rules('id','id');
        $this->form_validation->set_rules('nama','nama','required');
        $this->form_validation->set_rules('alamat','alamat','required');
        $this->form_validation->set_rules('tlp','tlp','required');

        if($this->form_validation->run() != false){
    
            $id = $this->input->post('id');
            $nama = $this->input->post('nama');
            $alamat = $this->input->post('alamat');
            $tlp = $this->input->post('tlp');

            $data = array(
                'id' => $id,
                'nama' => $nama,
                'alamat' => $alamat,
                'tlp' => $tlp
            );

            $this->m_data->insert_data($data,'tb_outlet');
    
            redirect(base_url().'outlet');

        }else{

            $this->load->view('template/header');
            $this->load->view('outlet/input');
            $this->load->view('template/footer');
        }
    }

    public function outlet_edit($id)
    {
        $where = array(
            'id' => $id
            );

            $data['outlet'] = $this->m_data->edit_data($where,'tb_outlet')->result();
            $this->load->view('template/header');
            $this->load->view('outlet/edit',$data);
            $this->load->view('template/footer');
    }

    public function outlet_update()
    {

        $this->form_validation->set_rules('id','id');
        $this->form_validation->set_rules('nama','nama','required');
        $this->form_validation->set_rules('alamat','alamat','required');
        $this->form_validation->set_rules('tlp','tlp','required');

        if($this->form_validation->run() != false){
    
            $id = $this->input->post('id');
            $nama = $this->input->post('nama');
            $alamat = $this->input->post('alamat');
            $tlp = $this->input->post('tlp');
    
            $where = array(
                'id' => $id
        );

        $data = array(
            'nama' => $nama,
            'alamat' => $alamat,
            'tlp' => $tlp
        );

        $this->m_data->update_data($where, $data,'tb_outlet');

        redirect(base_url().'outlet');
    
    }else{

        $id = $this->input->post('id');

        $where = array(
            'id' => $id
        );

        $data['outlet'] = $this->m_data->edit_data($where,'tb_outlet')->result();
        $this->load->view('template/header');
        $this->load->view('outlet/edit',$data);
        $this->load->view('template/footer');

    }
}
    public function outlet_hapus($id)
    {
        $where = array(
            'id' => $id
        );

        $this->m_data->delete_data($where,'tb_outlet');

        redirect(base_url().'outlet');
    }
    //CRUD END     
}