<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Member extends CI_Controller {

    function __construct()
    {
        parent::__construct();

        $this->load->model('m_data');

        if($this->session->userdata('status')!="telah_login"){
            redirect(base_url().'login?alert=belum_login');
        }
    }

// CRUD Member
    public function index()
    {
        $data['member'] = $this->m_data->get_data('tb_member')->result();
        $this->load->view('template/header');
        $this->load->view('member/data',$data);
        $this->load->view('template/footer');

    }

    public function member_tambah()
    {
        $this->load->view('template/header');
        $this->load->view('member/input');
        $this->load->view('template/footer');
    }
    public function member_aksi()
    {

        $this->form_validation->set_rules('id','id');
        $this->form_validation->set_rules('nama','nama','required');
        $this->form_validation->set_rules('alamat','alamat','required');
        $this->form_validation->set_rules('jenis_kelamin','jenis_kelamin','required');
        $this->form_validation->set_rules('tlp','tlp','required');

        if($this->form_validation->run() != false){
    
            $id = $this->input->post('id');
            $nama = $this->input->post('nama');
            $alamat = $this->input->post('alamat');
            $jenis_kelamin = $this->input->post('jenis_kelamin');
            $tlp = $this->input->post('tlp');

            $data = array(
                'id' => $id,
                'nama' => $nama,
                'alamat' => $alamat,
                'jenis_kelamin' => $jenis_kelamin,
                'tlp' => $tlp
            );

            $this->m_data->insert_data($data,'tb_member');
    
            redirect(base_url().'member');

        }else{

            $this->load->view('template/header');
            $this->load->view('member/input');
            $this->load->view('template/footer');
        }
    }

    public function member_edit($id)
    {
        $where = array(
            'id' => $id
            );

            $data['member'] = $this->m_data->edit_data($where,'tb_member')->result();
            $this->load->view('template/header');
            $this->load->view('member/edit',$data);
            $this->load->view('template/footer');
    }

    public function member_update()
    {

        $this->form_validation->set_rules('id','id');
        $this->form_validation->set_rules('nama','nama','required');
        $this->form_validation->set_rules('alamat','alamat','required');
        $this->form_validation->set_rules('jenis_kelamin','jenis_kelamin','required');
        $this->form_validation->set_rules('tlp','tlp','required');

        if($this->form_validation->run() != false){
    
            $id = $this->input->post('id');
            $nama = $this->input->post('nama');
            $alamat = $this->input->post('alamat');
            $jenis_kelamin = $this->input->post('jenis_kelamin');
            $tlp = $this->input->post('tlp');
    
            $where = array(
                'id' => $id
        );

        $data = array(
            'nama' => $nama,
            'alamat' => $alamat,
            'jenis_kelamin' => $jenis_kelamin,
            'tlp' => $tlp
        );

        $this->m_data->update_data($where, $data,'tb_member');

        redirect(base_url().'member');
    
    }else{

        $id = $this->input->post('id');

        $where = array(
            'id' => $id
        );

        $data['member'] = $this->m_data->edit_data($where,'tb_member')->result();
        $this->load->view('template/header');
        $this->load->view('member/edit',$data);
        $this->load->view('template/footer');

    }
}
    public function member_hapus($id)
    {
        $where = array(
            'id' => $id
        );

        $this->m_data->delete_data($where,'tb_member');

        redirect(base_url().'member');
    }
    //CRUD END     
}