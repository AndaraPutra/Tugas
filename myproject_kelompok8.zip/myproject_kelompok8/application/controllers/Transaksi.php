<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Transaksi extends CI_Controller {

    function __construct()
    {
        parent::__construct();

        $this->load->model('m_data');

        if($this->session->userdata('status')!="telah_login"){
            redirect(base_url().'login?alert=belum_login');
        }
    }

// CRUD transaksi
    public function index()
    {
        $data['transaksi'] = $this->m_data->get_data('tb_transaksi')->result();
        $this->load->view('template/header');
        $this->load->view('transaksi/data',$data);
        $this->load->view('template/footer');

    }

    public function transaksi_tambah()
    {
        $data['member'] = $this->m_data->get_data('tb_member')->result();
        $data['user'] = $this->m_data->get_data('tb_user')->result();
        $data['outlet'] = $this->m_data->get_data('tb_outlet')->result();
        $this->load->view('template/header');
        $this->load->view('transaksi/input',$data);
        $this->load->view('template/footer');
    }
    public function transaksi_aksi()
    {

        $this->form_validation->set_rules('id','id');
        $this->form_validation->set_rules('id_outlet','id_outlet','required');
        $this->form_validation->set_rules('kode_invoice','kode_invoice','required');
        $this->form_validation->set_rules('id_member','id_member','required');
        $this->form_validation->set_rules('tgl','tgl','required');
        $this->form_validation->set_rules('batas_waktu','batas_waktu','required');
        $this->form_validation->set_rules('tgl_bayar','tgl_bayar','required');
        $this->form_validation->set_rules('biaya_tambahan','biaya_tambahan','required');
        $this->form_validation->set_rules('diskon','diskon','required');
        $this->form_validation->set_rules('pajak','pajak','required');
        $this->form_validation->set_rules('status','status','required');
        $this->form_validation->set_rules('dibayar','dibayar','required');
        $this->form_validation->set_rules('id_user','id_user','required');

        if($this->form_validation->run() != false){
    
            $id = $this->input->post('id');
            $id_outlet = $this->input->post('id_outlet');
            $kode_invoice = $this->input->post('kode_invoice');
            $id_member = $this->input->post('id_member');
            $tgl = $this->input->post('tgl');
            $batas_waktu = $this->input->post('batas_waktu');
            $tgl_bayar = $this->input->post('tgl_bayar');
            $biaya_tambahan = $this->input->post('biaya_tambahan');
            $diskon = $this->input->post('diskon');
            $pajak = $this->input->post('pajak');
            $status = $this->input->post('status');
            $dibayar = $this->input->post('dibayar');
            $id_user = $this->input->post('id_user');

            $data = array(
                'id' => $id,
                'id_outlet' => $id_outlet,
                'kode_invoice' => $kode_invoice,
                'id_member' => $id_member,
                'tgl' => $tgl,
                'batas_waktu' => $batas_waktu,
                'tgl_bayar' => $tgl_bayar,
                'biaya_tambahan' => $biaya_tambahan,
                'diskon' => $diskon,
                'pajak' => $pajak,
                'status' => $status,
                'dibayar' => $dibayar,
                'id_user' => $id_user
            );

            $this->m_data->insert_data($data,'tb_transaksi');
    
            redirect(base_url().'transaksi');

        }else{

            $this->load->view('template/header');
            $this->load->view('transaksi/input');
            $this->load->view('template/footer');
        }
    }

    public function transaksi_edit($id)
    {
        $where = array(
            'id' => $id
            );

            $data['transaksi'] = $this->m_data->edit_data($where,'tb_transaksi')->result();
            $data['member'] = $this->m_data->get_data('tb_member')->result();
            $data['user'] = $this->m_data->get_data('tb_user')->result();
            $data['outlet'] = $this->m_data->get_data('tb_outlet')->result();    
            $this->load->view('template/header');
            $this->load->view('transaksi/edit',$data);
            $this->load->view('template/footer');
    }

    public function transaksi_update()
    {

        $this->form_validation->set_rules('id','id');
        $this->form_validation->set_rules('id_outlet','id_outlet','required');
        $this->form_validation->set_rules('kode_invoice','kode_invoice','required');
        $this->form_validation->set_rules('id_member','id_member','required');
        $this->form_validation->set_rules('tgl','tgl','required');
        $this->form_validation->set_rules('batas_waktu','batas_waktu','required');
        $this->form_validation->set_rules('tgl_bayar','tgl_bayar','required');
        $this->form_validation->set_rules('biaya_tambahan','biaya_tambahan','required');
        $this->form_validation->set_rules('diskon','diskon','required');
        $this->form_validation->set_rules('pajak','pajak','required');
        $this->form_validation->set_rules('status','status','required');
        $this->form_validation->set_rules('dibayar','dibayar','required');
        $this->form_validation->set_rules('id_user','id_user','required');

        if($this->form_validation->run() != false){
    
            $id = $this->input->post('id');
            $id_outlet = $this->input->post('id_outlet');
            $kode_invoice = $this->input->post('kode_invoice');
            $id_member = $this->input->post('id_member');
            $tgl = $this->input->post('tgl');
            $batas_waktu = $this->input->post('batas_waktu');
            $tgl_bayar = $this->input->post('tgl_bayar');
            $biaya_tambahan = $this->input->post('biaya_tambahan');
            $diskon = $this->input->post('diskon');
            $pajak = $this->input->post('pajak');
            $status = $this->input->post('status');
            $dibayar = $this->input->post('dibayar');
            $id_user = $this->input->post('id_user');
    
            $where = array(
                'id' => $id
        );

        $data = array(
            'id' => $id,
            'id_outlet' => $id_outlet,
            'kode_invoice' => $kode_invoice,
            'id_member' => $id_member,
            'tgl' => $tgl,
            'batas_waktu' => $batas_waktu,
            'tgl_bayar' => $tgl_bayar,
            'biaya_tambahan' => $biaya_tambahan,
            'diskon' => $diskon,
            'pajak' => $pajak,
            'status' => $status,
            'dibayar' => $dibayar,
            'id_user' => $id_user
    );

        $this->m_data->update_data($where, $data,'tb_transaksi');

        redirect(base_url().'transaksi');
    
    }else{

        $id = $this->input->post('id');

        $where = array(
            'id' => $id
        );

        $data['transaksi'] = $this->m_data->edit_data($where,'tb_transaksi')->result();
        $this->load->view('template/header');
        $this->load->view('transaksi/edit',$data);
        $this->load->view('template/footer');

    }
}
    public function transaksi_hapus($id)
    {
        $where = array(
            'id' => $id
        );

        $this->m_data->delete_data($where,'tb_transaksi');

        redirect(base_url().'transaksi');
    }
    //CRUD END     
}