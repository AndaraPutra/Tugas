<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

    public function index()
    {
        $this->load->view('login/form_login');
    }
    public function ceklogin()
    {
        $this->form_validation->set_rules('email', 'Email', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');

        if($this->form_validation->run() != false){

            $username = $this->input->post('email');
            $password = $this->input->post('password');
        
            $where = array(
                'username' => $username,
                'password' => md5($password)
            );

        $this->load->model('m_data');

        $cek = $this->m_data->cek_login('tb_user',$where)->num_rows();

        if($cek > 0){

            $data = $this->m_data->cek_login('tb_user',$where)->row();
            $role = $data->role;
            if ($role=='admin') {

            $data_session = array(
                'id' => $data->id_user,
                'nama' => $data->nama,
                'username' => $data->username,
                'role' => $data->role,
                'status' => 'telah_login'
            );
            $this->session->set_userdata($data_session);

            redirect(base_url().'admin');
            }elseif ($role=='kasir') {
                
            $data_session = array(
                'id' => $data->id_user,
                'nama' => $data->nama,
                'username' => $data->username,
                'role' => $data->role,
                'status' => 'telah_login'
            );
            $this->session->set_userdata($data_session);

            redirect(base_url().'kasir');
            }elseif ($role=='owner') {

            $data_session = array(
                'id' => $data->id_user,
                'nama' => $data->nama,
                'username' => $data->username,
                'role' => $data->role,
                'status' => 'telah_login'
            );
            $this->session->set_userdata($data_session);

            redirect(base_url().'owner');
            }
        }else{
            redirect(base_url().'login?alert=gagal');
        }
    }else{
            $this->load->view('login/Form_login');

        }
    }
}
