<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Paket extends CI_Controller {

    function __construct()
    {
        parent::__construct();

        $this->load->model('m_data');

        if($this->session->userdata('status')!="telah_login"){
            redirect(base_url().'login?alert=belum_login');
        }
    }

    // CRUD paket
    public function index()
    {
        $data['paket'] = $this->m_data->get_data('tb_paket')->result();
        $this->load->view('template/header');
        $this->load->view('paket/data',$data);
        $this->load->view('template/footer');

    }

    public function paket_tambah()
    {
        $data['outlet'] = $this->m_data->get_data('tb_outlet')->result();
        $this->load->view('template/header');
        $this->load->view('paket/input',$data);
        $this->load->view('template/footer');
    }

    public function paket_aksi()
    {
        $this->form_validation->set_rules('id','id');
        $this->form_validation->set_rules('id_outlet','id_outlet','required');
        $this->form_validation->set_rules('jenis','jenis','required');
        $this->form_validation->set_rules('nama_paket','nama_paket','required');
        $this->form_validation->set_rules('harga','harga','required');

        if($this->form_validation->run() != false){
    
            $id = $this->input->post('id');
            $id_outlet = $this->input->post('id_outlet');
            $jenis = $this->input->post('jenis');
            $nama_paket = $this->input->post('nama_paket');
            $harga = $this->input->post('harga');

            $data = array(
                'id' => $id,
                'id_outlet' => $id_outlet,
                'jenis' => $jenis,
                'nama_paket' => $nama_paket,
                'harga' => $harga
            );

            $this->m_data->insert_data($data,'tb_paket');
    
            redirect(base_url().'paket');

        }else{

            $this->load->view('template/header');
            $this->load->view('paket/input');
            $this->load->view('template/footer');
        }
    }

    public function paket_edit($id)
    {
        $where = array(
            'id' => $id
            );
            
            $data['outlet'] = $this->m_data->get_data('tb_outlet')->result();
            $data['paket'] = $this->m_data->edit_data($where,'tb_paket')->result();
            $this->load->view('template/header');
            $this->load->view('paket/edit',$data);
            $this->load->view('template/footer');
    }

    public function paket_update()
    {

        $this->form_validation->set_rules('id','id');
        $this->form_validation->set_rules('id_outlet','id_outlet','required');
        $this->form_validation->set_rules('jenis','jenis','required');
        $this->form_validation->set_rules('nama_paket','nama_paket','required');
        $this->form_validation->set_rules('harga','harga','required');

        if($this->form_validation->run() != false){
    
            $id = $this->input->post('id');
            $id_outlet = $this->input->post('id_outlet');
            $jenis = $this->input->post('jenis');
            $nama_paket = $this->input->post('nama_paket');
            $harga = $this->input->post('harga');
    
            $where = array(
                'id' => $id
        );

        $data = array(
            'id_outlet' => $id_outlet,
            'jenis' => $jenis,
            'nama_paket' => $nama_paket,
            'harga' => $harga
        );

        $this->m_data->update_data($where, $data,'tb_paket');

        redirect(base_url().'paket');
    
    }else{

        $id = $this->input->post('id');

        $where = array(
            'id' => $id
        );

        $data['paket'] = $this->m_data->edit_data($where,'tb_paket')->result();
        $this->load->view('template/header');
        $this->load->view('paket/edit',$data);
        $this->load->view('template/footer');

    }
}
    public function paket_hapus($id)
    {
        $where = array(
            'id' => $id
        );

        $this->m_data->delete_data($where,'tb_paket');

        redirect(base_url().'paket');
    }
    //CRUD END     
}