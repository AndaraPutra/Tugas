<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Laporan extends CI_Controller {

    function __construct()
    {
        parent::__construct();

        $this->load->model('m_data');
    }

    public function index()
    {
   
    $this->load->library('pdfgenerator');
    
   
    $this->data['title_pdf'] = 'Laporan Penjualan Toko Kita';
    
   
    $file_pdf = 'laporan_transaksi';
   
    $paper = 'A4';
   
    $orientation = "landscape";
    $data['transaksi'] = $this->m_data->get_data('tb_transaksi')->result();
    $html = $this->load->view('transaksi/laporan',$data, true); 
    
   
    $this->pdfgenerator->generate($html, $file_pdf,$paper,$orientation);
    }
}