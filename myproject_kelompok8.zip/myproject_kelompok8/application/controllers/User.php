<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

    function __construct()
    {
        parent::__construct();

        $this->load->model('m_data');

        if($this->session->userdata('status')!="telah_login"){
            redirect(base_url().'login?alert=belum_login');
        }
    }

    // CRUD user
    public function index()
    {
        $data['user'] = $this->m_data->get_data('tb_user')->result();
        $this->load->view('template/header');
        $this->load->view('user/data',$data);
        $this->load->view('template/footer');

    }

    public function user_tambah()
    {
        $data['outlet'] = $this->m_data->get_data('tb_outlet')->result();
        $this->load->view('template/header');
        $this->load->view('user/input',$data);
        $this->load->view('template/footer');
    }

    public function user_aksi()
    {
        $this->form_validation->set_rules('id','id');
        $this->form_validation->set_rules('nama','nama','required');
        $this->form_validation->set_rules('username','username','required');
        $this->form_validation->set_rules('password','password','required');
        $this->form_validation->set_rules('id_outlet','id_outlet','required');
        $this->form_validation->set_rules('role','role','required');

        if($this->form_validation->run() != false){
    
            $id = $this->input->post('id');
            $nama = $this->input->post('nama');
            $username = $this->input->post('username');
            $password = $this->input->post('password');
            $id_outlet = $this->input->post('id_outlet');
            $role = $this->input->post('role');

            $data = array(
                'id' => $id,
                'nama' => $nama,
                'username' => $username,
                'password' => md5($password),
                'id_outlet' => $id_outlet,
                'role' => $role
            );

            $this->m_data->insert_data($data,'tb_user');
    
            redirect(base_url().'user');

        }else{

            $this->load->view('template/header');
            $this->load->view('user/input');
            $this->load->view('template/footer');
        }
    }

    public function user_edit($id)
    {
        $where = array(
            'id' => $id
            );
            
            $data['outlet'] = $this->m_data->get_data('tb_outlet')->result();
            $data['user'] = $this->m_data->edit_data($where,'tb_user')->result();
            $this->load->view('template/header');
            $this->load->view('user/edit',$data);
            $this->load->view('template/footer');
    }

    public function user_update()
    {

        $this->form_validation->set_rules('id','id');
        $this->form_validation->set_rules('nama','nama','required');
        $this->form_validation->set_rules('username','username','required');
        $this->form_validation->set_rules('password','password','required');
        $this->form_validation->set_rules('id_outlet','id_outlet','required');
        $this->form_validation->set_rules('role','role','required');

        if($this->form_validation->run() != false){
    
            $id = $this->input->post('id');
            $nama = $this->input->post('nama');
            $username = $this->input->post('username');
            $password = $this->input->post('password');
            $id_outlet = $this->input->post('id_outlet');
            $role = $this->input->post('role');
    
            $where = array(
                'id' => $id
        );

        $data = array(
            'nama' => $nama,
            'username' => $username,
            'password' => md5($password),
            'id_outlet' => $id_outlet,
            'role' => $role
        );

        $this->m_data->update_data($where, $data,'tb_user');

        redirect(base_url().'user');
    
    }else{

        $id = $this->input->post('id');

        $where = array(
            'id' => $id
        );

        $data['user'] = $this->m_data->edit_data($where,'tb_user')->result();
        $this->load->view('template/header');
        $this->load->view('user/edit',$data);
        $this->load->view('template/footer');

    }
}
    public function user_hapus($id)
    {
        $where = array(
            'id' => $id
        );

        $this->m_data->delete_data($where,'tb_user');

        redirect(base_url().'user');
    }
    //CRUD END     
}