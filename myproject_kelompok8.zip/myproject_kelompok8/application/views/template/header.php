<!doctype html>
<html lang="en">

<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<!-- Meta -->
	<meta name="description" content="Responsive Bootstrap4 Dashboard Template">
	<meta name="author" content="ParkerThemes">
	<link rel="shortcut icon" href="img/fav.png">

	<!-- Title -->
	<title>UGA Laundry - <?php echo $this->session->userdata('role') ?> Dashboard</title>


	<!-- *************
			************ Common Css Files *************
		************ -->
	<!-- Bootstrap css -->
	<link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css') ?>">

	<!-- Icomoon Font Icons css -->
	<link rel="stylesheet" href="<?php echo base_url('assets/fonts/style.css') ?>">

	<!-- Main css -->
	<link rel="stylesheet" href="<?php echo base_url('assets/css/main.css') ?>">


	<!-- *************
			************ Vendor Css Files *************
		************ -->

	<!-- Mega Menu -->
	<link rel="stylesheet" href="<?php echo base_url('assets/vendor/megamenu/css/megamenu.css') ?>">

	<!-- Search Filter JS -->
	<link rel="stylesheet" href="<?php echo base_url('assets/vendor/search-filter/search-filter.css') ?>">
	<link rel="stylesheet" href="<?php echo base_url('assets/vendor/search-filter/custom-search-filter.css') ?>">

</head>

<body class="slim-sidebar">

	<!-- Loading wrapper start -->
	<!-- <div id="loading-wrapper"> -->
	<!-- <div class="spinner-border"></div> -->
	<!-- </div> -->
	<!-- Loading wrapper end -->

	<!-- Page wrapper start -->
	<div class="page-wrapper">

		<!-- Sidebar wrapper start -->
		<nav class="sidebar-wrapper">

			<!-- Default sidebar wrapper start -->
			<div class="default-sidebar-wrapper">

				<!-- Sidebar brand starts -->
				<div class="default-sidebar-brand">
					<a href="<?php echo base_url('dashboard') ?>" class="logo">
						<img src="<?php echo base_url('assets/img/logo.svg') ?>" alt="Uni Pro Admin Dashboard" />
					</a>
				</div>
				<!-- Sidebar brand starts -->

				<!-- Sidebar menu starts -->
				<div class="defaultSidebarMenuScroll">
					<div class="default-sidebar-menu">
						<ul>

							<li class="default-sidebar-dropdown ">
								<a href="<?php echo base_url('member') ?>">
									<i class="icon-users"></i>
									<span class="menu-text">Member</span>
								</a>
							</li>
							<li class="default-sidebar-dropdown">
								<a href="<?php echo base_url('paket') ?>">
									<i class="icon-box"></i>
									<span class="menu-text">Paket</span>
								</a>
							</li>
							<li class="default-sidebar-dropdown">
								<a href="<?php echo base_url('outlet') ?>">
									<i class="icon-home"></i>
									<span class="menu-text">Outlet</span>
								</a>
							</li>
							<li class="default-sidebar-dropdown">
								<a href="<?php echo base_url('user') ?>">
									<i class="icon-user"></i>
									<span class="menu-text">User</span>
								</a>
							</li>
							<li class="default-sidebar-dropdown">
								<a href="<?php echo base_url('transaksi') ?>">
									<i class="icon-shopping-cart"></i>
									<span class="menu-text">Transaksi</span>
								</a>
							</li>
						</ul>
					</div>
				</div>
				<!-- Sidebar menu ends -->

			</div>
			<!-- Default sidebar wrapper end -->

		</nav>
		<!-- Sidebar wrapper end -->

		<!-- *************
				************ Main container start *************
			************* -->
		<div class="main-container">

			<!-- Page header starts -->
			<div class="page-header">

				<!-- Row start -->
				<div class="row gutters">
					<div class="col-xl-6 col-lg-6 col-md-8 col-sm-6 col-9">

						<!-- Search container start -->
						<div class="search-container">

							<!-- Toggle sidebar start -->
							<div class="toggle-sidebar" id="toggle-sidebar">
								<i class="icon-menu"></i>
							</div>
							<!-- Toggle sidebar end -->

						</div>
						<!-- Search container end -->

					</div>
					<div class="col-xl-6 col-lg-6 col-md-4 col-sm-6 col-3">

						<!-- Header actions start -->
						<ul class="header-actions">
							<li class="dropdown">
								<a href="#" id="userSettings" class="user-settings" data-toggle="dropdown" aria-haspopup="true">
									<span class="avatar">
										<img src="<?php echo base_url('assets/img/user.svg') ?>" alt="User Avatar">
										<span class="status busy"></span>
									</span>
								</a>
								<div class="dropdown-menu dropdown-menu-end md" aria-labelledby="userSettings">
									<div class="header-profile-actions">
										<a href="<?php echo base_url('dashboard') ?>"><i class="icon-user1"></i>Profile</a>
										<a href="<?php echo base_url('user') ?>"><i class="icon-settings1"></i>Settings</a>
										<a href="<?php echo base_url('admin/keluar') ?>"><i class="icon-log-out1"></i>Logout</a>
									</div>
								</div>
							</li>
						</ul>
						<!-- Header actions end -->

					</div>
				</div>
				<!-- Row end -->

			</div>
			<!-- Page header ends -->

			<!-- Content wrapper scroll start -->
			<div class="content-wrapper-scroll">

				<!-- Content wrapper start -->
				<div class="content-wrapper">

					<!-- Breadcrumb container start -->
					<div class="breadcrumb-container">

						<!-- Row start -->
						<div class="row gutters">
							<div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
								<nav aria-label="breadcrumb">
									<ol class="breadcrumb">
										<li class="breadcrumb-item"><a href="index.html">Home</a></li>
										<li class="breadcrumb-item">Layouts</li>
										<li class="breadcrumb-item active" aria-current="page">Layout Slim Sidebar</li>
									</ol>
								</nav>
							</div>
							<div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
								<!-- Top Actions - DateRange and Buttons -->
								<div class="d-flex justify-content-end">
									<a href="<?php echo base_url('laporan') ?>" class="btn btn-info"><i class="icon-file"></i> Laporan</a>
								</div>
							</div>
						</div>
						<!-- Row end -->

					</div>
					<!-- Breadcrumb container end -->