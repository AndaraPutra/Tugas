</div>
					<!-- Content wrapper end -->

					<!-- App Footer start -->
					<div class="app-footer">© GHE Laundry 2022</div>
					<!-- App footer end -->

				</div>
				<!-- Content wrapper scroll end -->

			</div>
			<!-- *************
				************ Main container end *************
			************* -->

		</div>
		<!-- Page wrapper end -->

		<!-- *************
			************ Required JavaScript Files *************
		************* -->
		<!-- Required jQuery first, then Bootstrap Bundle JS -->
		<script src="<?php echo base_url('assets/js/jquery.min.js') ?>"></script>
		<script src="<?php echo base_url('assets/js/bootstrap.bundle.min.js') ?>"></script>
		<script src="<?php echo base_url('assets/js/modernizr.js') ?>"></script>
		<script src="<?php echo base_url('assets/js/moment.js') ?>"></script>

		<!-- *************
			************ Vendor Js Files *************
		************* -->
		
		<!-- Megamenu JS -->
		<script src="<?php echo base_url('assets/vendor/megamenu/js/megamenu.js') ?>"></script>
		<script src="<?php echo base_url('assets/vendor/megamenu/js/custom.js') ?>"></script>

		<!-- Slimscroll JS -->
		<script src="<?php echo base_url('assets/vendor/slimscroll/slimscroll.min.js') ?>"></script>
		<script src="<?php echo base_url('assets/vendor/slimscroll/custom-scrollbar.js') ?>"></script>

		<!-- Search Filter JS -->
		<script src="<?php echo base_url('assets/vendor/search-filter/search-filter.js') ?>"></script>
		<script src="<?php echo base_url('assets/vendor/search-filter/custom-search-filter.js') ?>"></script>

		<!-- Main Js Required -->
		<script src="<?php echo base_url('assets/js/main.js') ?>"></script>

	</body>
</html>