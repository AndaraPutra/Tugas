<div class="row gutters">
    <div class="col-xl-12">
        <div class="card">
            <div class="card-body">
            <h1> Welcome <?php echo $this->session->userdata('nama') ?> </h1>
            <h3> ID Anda    : <?php echo $this->session->userdata('id') ?> </h3>
            <h3> Ini        : <?php echo $this->session->userdata('username') ?> Email Anda </h3>
            </div>
        </div>
    </div>
</div>


