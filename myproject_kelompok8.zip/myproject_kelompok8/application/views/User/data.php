<!-- Row start -->
<div class="row gutters">
    <div class="col-xl-12">
        <!-- Card start -->
        <div class="card">
            <div class="card-header">
                <div class="card-title"><h3> Data User</h3></div>
            </div>
            <div class="card-body">
            <br/>
                <a class="btn btn-primary" href="<?php echo base_url().'User' ?>" role="button">Kembali</a>
            <?php if ($this->session->userdata('role')=== 'admin'): ?>             
                <a class="btn btn-primary" href="<?php echo base_url().'User/User_tambah' ?>" role="button">Tambah Data Member</a><br/>
            <?php endif;?>
                <table class="table table-striped table-bordered">
                <thead class="text-center">
                    <tr>
                    <th Scope="col">No </th>
                    <th scope="col">Id User</th>
                    <th scope="col">Nama</th>
                    <th scope="col">Username</th>
                    <th scope="col">Password</th>
                    <th scope="col">Id Outlet</th>
                    <th scope="col">Role</th>
                    <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody class="text-center">
                <?php
                    $no = 1;
                    foreach($user as $p){
                    ?>
                    <tr>
                    <th scope="row"><?php echo $no++; ?></th>
                    <td><?php echo $p->id; ?></td>
                    <td><?php echo $p->nama; ?></td>
                    <td><?php echo $p->username; ?></td>
                    <td><?php echo $p->password; ?></td>
                    <td><?php echo $p->id_outlet; ?></td>
                    <td><?php echo $p->role; ?></td>
                    <td class="text-center">
                    <?php if ($this->session->userdata('role')=== 'admin'): ?>
                        <a href="<?php echo base_url().'User/User_edit/'.$p->id; ?>" class="btn btn-warning btn-sm"> Edit</a>
                        <a href="<?php echo base_url().'User/User_hapus/'.$p->id; ?>" class="btn btn-danger btn-sm"> Hapus</a>
                    <?php endif;?>
                    </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>

            <hr/>

            </div>
        </div>
        <!-- Card end -->
    </div>
</div>
<!-- Row end -->
