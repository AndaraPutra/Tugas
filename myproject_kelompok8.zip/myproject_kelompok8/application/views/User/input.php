<!-- Row start -->
<div class="row gutters">
    <div class="col-xl-12">
        <!-- Card start -->
        <div class="card">
            <div class="card-header">
                <div class="card-title"><h3>Tambah Data User</div></h3>
            </div>
        <br/>
        <form method="post" action="<?php echo base_url('user/user_aksi') ?>" enctype="multipart/form-data">
        <div class="row">
            <div class="col">
            <div class="card">
                <div class="card-body">
                <div class="mb-3 row">
                    <label for="staticEmail" class="col-sm-2 col-formlabel">Id user</label>
                    <div class="col-sm-10">
                    <input type="text" name="id" class="form-control" readonly>
                    </div>
                    <?php echo form_error('id'); ?>
                </div>
                <div class="mb-3 row">
                    <label for="inputPassword" class="col-sm-2 col-formlabel">Nama</label>
                    <div class="col-sm-10">
                    <input type="text" class="form-control" id="inputPassword" name="nama" >
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="inputPassword" class="col-sm-2 col-formlabel">Username</label>
                    <div class="col-sm-10">
                    <input type="text" class="form-control" id="inputPassword" name="username" >
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="inputPassword" class="col-sm-2 col-formlabel">Password</label>
                    <div class="col-sm-10">
                    <input type="text" class="form-control" id="inputPassword" name="password" >
                    </div>
                </div>
                <div class="mb-3 row">
                <label for="inputPassword" class="col-sm-2 col-formlabel">Id Outlet</label>
                    <div class="col-sm-10">
                    <select class="form-select" aria-label="Default select example" name="id_outlet">
                        <option selected>Pilih Outlet</option>
                        <?php foreach($outlet as $o) : ?>
                        <option value="<?php echo $o->id; ?>"><?php echo $o->id; ?></option>
                        <?php endforeach ; ?>
                        </select>
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="inputPassword" class="col-sm-2 col-formlabel">Role</label>
                    <div class="col-sm-10">
                    <select class="form-select" arialabel="Default select example" name="role">
                        <option selected>Pilih</option>
                        <option value="admin">Admin</option>
                        <option value="kasir">Kasir</option>
                        <option value="owner">Owner</option>
                    </select>
                    </div>
                </div>

                <a class="btn btn-primary" href="<?php echo base_url().'user' ?>" role="button">kembali</a>
                <input type="submit" class="btn btn-success " value="Tambah Data User">
                </div>
            </div>
            </div>
        </form>
        <!-- Card end -->
    </div>
</div>
<!-- Row end -->
