<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?= $title_pdf;?></title>
        <style>
            #table {
            font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }
        #table td, #table th {
            border: 1px solid #ddd;
            padding: 8px;
        }
        #table tr:nth-child(even){background-color: #f2f2f2;}
        #table tr:hover {background-color: #ddd;}
        #table th {
            padding-top: 10px;
            padding-bottom: 10px;
            text-align: left;
            background-color: #4CAF50;
            color: white;
        }
        </style>
 </head>
 <body>
    <div style="text-align:center">
        <h3> Laporan Data Transaksi</h3>
    </div>
    <table id="table">
        <thead>
            <tr>
                    <th Scope="col">No </th>
                    <th Scope="col">ID </th>
                    <th scope="col">Id Outlet</th>
                    <th scope="col">Kode Invoice</th>
                    <th scope="col">ID Member</th>
                    <th scope="col">Tanggal</th>
                    <th scope="col">Batas Waktu</th>
                    <th scope="col">Tanggal Bayar</th>
                    <th scope="col">Status</th>
                    <th scope="col">Dibayar</th>
            </tr>
        </thead>
        <tbody>
        <?php
            $no = 1;
            foreach($transaksi as $t){
        ?>
            <tr>
                    <th scope="row"><?php echo $no++; ?></th>
                    <td><?php echo $t->id; ?></td>
                    <td><?php echo $t->id_outlet; ?></td>
                    <td><?php echo $t->kode_invoice; ?></td>
                    <td><?php echo $t->id_member; ?></td>
                    <td><?php echo $t->tgl; ?></td>
                    <td><?php echo $t->batas_waktu; ?></td>
                    <td><?php echo $t->tgl_bayar; ?></td>
                    <td><?php echo $t->status; ?></td>
                    <td><?php echo $t->dibayar; ?></td>
            </tr>
        <?php } ?>
        </tbody>
    </table>
</body>
</html>
