<!-- Row start -->
<div class="row gutters">
    <div class="col-xl-12">
        <!-- Card start -->
        <div class="card">
            <div class="card-header">
                <div class="card-title"><h3>Transaksi</div></h3>
            </div>
        <br/>
        <form method="post" action="<?php echo base_url('transaksi/transaksi_aksi') ?>" enctype="multipart/form-data">
        <div class="row">
            <div class="col">
            <div class="card">
                <div class="card-body">
                <div class="mb-3 row">
                    <label for="staticEmail" class="col-sm-2 col-formlabel">Id transaksi</label>
                    <div class="col-sm-10">
                    <input type="text" name="id" class="form-control" readonly>
                    </div>
                    <?php echo form_error('id'); ?>
                </div>
               <div class="mb-3 row">
                    <label for="inputPassword" class="col-sm-2 col-formlabel">Id Outlet</label>
                    <div class="col-sm-10">
                    <select class="form-select" aria-label="Default select example" name="id_outlet">
                        <option selected>Pilih Outlet</option>
                        <?php foreach($outlet as $o) : ?>
                        <option value="<?php echo $o->id; ?>"><?php echo $o->id; ?></option>
                        <?php endforeach ; ?>
                        </select>
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="inputPassword" class="col-sm-2 col-form-label">Kode Invoice</label>
                    <div class="col-sm-10">
                    <input type="text" class="form-control" id="inputPassword" name="kode_invoice" >
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="inputPassword" class="col-sm-2 col-form-label">Id Member</label>
                    <div class="col-sm-10">
                    <select class="form-select" aria-label="Default select example" name="id_member">
                        <option selected>Pilih Member</option>
                        <?php foreach($member as $m) : ?>
                        <option value="<?php echo $m->id; ?>"><?php echo $m->id; ?></option>
                        <?php endforeach ; ?>
                        </select>
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="inputPassword" class="col-sm-2 col-form-label">Tanggal</label>
                    <div class="col-sm-10">
                    <input type="date" class="form-control" id="inputPassword" name="tgl">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="inputPassword" class="col-sm-2 col-form-label">Batas Waktu</label>
                    <div class="col-sm-10">
                    <input type="date" class="form-control" id="inputPassword" name="batas_waktu">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="inputPassword" class="col-sm-2 col-formlabel">Tanggal Bayar</label>
                    <div class="col-sm-10">
                    <input type="date" class="form-control" id="inputPassword" name="tgl_bayar">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="inputPassword" class="col-sm-2 col-formlabel">Biaya Tambahan</label>
                    <div class="col-sm-10">
                    <input type="text" class="form-control" id="inputPassword" name="biaya_tambahan">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="inputPassword" class="col-sm-2 col-formlabel">diskon</label>
                    <div class="col-sm-10">
                    <input type="text" class="form-control" id="inputPassword" name="diskon" >
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="inputPassword" class="col-sm-2 col-formlabel">Pajak</label>
                    <div class="col-sm-10">
                    <input type="text" class="form-control" id="inputPassword" name="pajak" >
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="inputPassword" class="col-sm-2 col-formlabel">Status</label>
                    <div class="col-sm-10">
                    <select class="form-select" arialabel="Default select example" name="status">
                        <option selected>Pilih Status</option>
                        <option value="baru">Baru</option>
                        <option value="proses">Proses</option>
                        <option value="selesai">Selesai</option>
                        <option value="diambil">Diambil</option>
                    </select>
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="inputPassword" class="col-sm-2 col-formlabel">Dibayar</label>
                    <div class="col-sm-10">
                    <select class="form-select" arialabel="Default select example" name="dibayar">
                        <option selected>Pilih</option>
                        <option value="dibayar">Dibayar</option>
                        <option value="belum_dibayar">Belum Dibayar</option>
                    </select>
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="inputPassword" class="col-sm-2 col-formlabel">Id User</label>
                    <div class="col-sm-10">
                    <select class="form-select" aria-label="Default select example" name="id_user">
                        <option selected>Pilih User</option>
                        <?php foreach($user as $u) : ?>
                        <option value="<?php echo $u->id; ?>"><?php echo $u->id; ?></option>
                        <?php endforeach ; ?>
                        </select>
                    </div>
                </div>
                <a class="btn btn-primary" href="<?php echo base_url().'transaksi' ?>" role="button">kembali</a>
                <input type="submit" class="btn btn-success " value="Tambah Data transaksi">
                </div>
            </div>
            </div>
        </form>
        <!-- Card end -->
    </div>
</div>
<!-- Row end -->
